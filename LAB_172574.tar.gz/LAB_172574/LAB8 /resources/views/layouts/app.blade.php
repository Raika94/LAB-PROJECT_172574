<!DOCTYPE html>
<html lang="en">
<head>
    <title>A Survey for UPM Academics</title>
    <h1>Rapid Survey on R&D Disciplines in UPM</h1>
    <p>Deputy Vice Chancellor's Office (Research and Innovation)</p>
    <a href="https://analytics.upm.edu.my/info" class="btn btn-info"><button type="button">Learn More</button></a><br>
    <!-- CSS And JavaScript -->
</head>

<style> table,th,td {
        border: 1px solid black;
        border-collapse:collapse;
    }
    th,td{
        padding: 5px;
        text-align: left;
    }</style>

<body>
<center><form>
        <table style="width100%">
                <tr>
                <th>Staff ID* </th>
                <td><input type="int" name="staffid" placeholder="eg. A05410"></td>
                </tr>
            <br>
            <tr>
                <th>Author Names* </th>
                <td><input type="text" name="authorname" placeholder="eg. Faridah Mohamed Arshad"></td>
            </tr>

            <br>
            <tr>
                <th>Fields of Research (FOR)*</th>
                <td>
                    <select name="FOR" placeholder="Type to search or select from this drop down list">
                        <option value = "4D, 5D, Nth Dimension Modelling">AD, 5D, Nth Dimension Modelling</option>
                        <option value = "Abnormal Psychology">Abnormal Psychology</option>
                        <option value = "Aboriginal Culture Studies">Aboriginal Culture Studies</option>
                    </select>
                </td>
            </tr>

            <tr>
                <th>Socio-economic Objectives(SEO)</th>
                <td>
                    <select name="SEO">
                        <option value = "Defence">Defence</option>
                        <option value = "Defence Equipment">Defence Equipment</option>
                        <option value = "Other Defence n.e.c">Other Defence n.e.c</option>
                    </select>
                </td>
            </tr>

            <tr>
                <th>Comments</th>
                <td><input type="text" name="comments"></td>
            </tr>
    </table>

    </form>
    <a href="https://analytics.upm.edu.my/info" class="btn btn-info"><button type="button" style="background-color: firebrick; color:white">Submit</button></a>
    <a href="https://analytics.upm.edu.my/info" class="btn btn-info"><button type="button" style="background-color: #d58512 ; color:white">Clear</button></a><br><br><br>

</center>
<footer>@ 2016 Universiti Putra Malaysia. All rights reserved.</footer>
</body>
</html>